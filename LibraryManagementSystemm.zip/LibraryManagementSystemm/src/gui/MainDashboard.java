package gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.GridLayout;

public class MainDashboard extends JFrame {
    public MainDashboard() {
        setTitle("Library Management");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(2, 1));

        JButton manageBooksButton = new JButton("Manage Books");
        manageBooksButton.addActionListener(e -> new BookManagement().setVisible(true));

        JButton manageBorrowersButton = new JButton("Manage Borrowers");
        manageBorrowersButton.addActionListener(e -> new BorrowerDOA().setVisible(true));

        add(manageBooksButton);
        add(manageBorrowersButton);
    }

    public static void main(String[] args) {
        new MainDashboard().setVisible(true);
    }
}
