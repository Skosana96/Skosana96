package gui;
        
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BookManagement extends JFrame {
    private JTable bookTable;
    private BookDOA bookDAO;

    public BookManagement() {
        setTitle("Manage Books");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        bookDAO = new BookDOA();

        // Layout and Components
        setLayout(new BorderLayout());

        // Table
        bookTable = new JTable();
        add(new JScrollPane(bookTable), BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Book");
        JButton editButton = new JButton("Edit Book");
        JButton deleteButton = new JButton("Delete Book");

        addButton.addActionListener(e -> addBook());
        editButton.addActionListener(e -> editBook());
        deleteButton.addActionListener(e -> deleteBook());

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadBooks();
    }

    private void loadBooks() {
        List<Book> books = bookDAO.getAllBooks();
        String[] columnNames = {"ID", "Title", "Author", "ISBN", "Year"};
        String[][] data = new String[books.size()][5];

        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            data[i][0] = String.valueOf(book.getBookId());
            data[i][1] = book.getTitle();
            data[i][2] = book.getAuthor();
            data[i][3]
