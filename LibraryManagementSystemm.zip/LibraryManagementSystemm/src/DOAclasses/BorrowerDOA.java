package DOAclasses;

import Entities.Borrower;
import database.DerbyDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BorrowerDOA {
  
    public void addBorrower(Borrower borrower) {
        Connection conn = DerbyDatabase.getConnection();
        if (conn != null) {
            try {
                String sql = "INSERT INTO Borrowers (name, email) VALUES (?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, borrower.getName());
                stmt.setString(2, borrower.getEmail());
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public List<Borrower> getAllBorrowers() {
        List<Borrower> borrowers = new ArrayList<>();
        Connection conn = DerbyDatabase.getConnection();
        if (conn != null) {
            try {
                String sql = "SELECT * FROM Borrowers";
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    Borrower borrower = new Borrower();
                    borrower.setBorrowerId(rs.getInt("borrower_id"));
                    borrower.setName(rs.getString("name"));
                    borrower.setEmail(rs.getString("email"));
                    borrowers.add(borrower);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return borrowers;
    }

    public void updateBorrower(Borrower borrower) {
        Connection conn = DerbyDatabase.getConnection();
        if (conn != null) {
            try {
                String sql = "UPDATE Borrowers SET name = ?, email = ? WHERE borrower_id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, borrower.getName());
                stmt.setString(2, borrower.getEmail());
                stmt.setInt(3, borrower.getBorrowerId());
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void deleteBorrower(int borrowerId) {
        Connection conn = DerbyDatabase.getConnection();
        if (conn != null) {
            try {
                String sql = "DELETE FROM Borrowers WHERE borrower_id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, borrowerId);
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}  

